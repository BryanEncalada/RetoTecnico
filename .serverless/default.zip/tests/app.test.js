const { describe, it, expect } = require('@jest/globals');

describe('Sample Test', () => {
  it('should pass', () => {
    expect(true).toBe(true);
  });
});